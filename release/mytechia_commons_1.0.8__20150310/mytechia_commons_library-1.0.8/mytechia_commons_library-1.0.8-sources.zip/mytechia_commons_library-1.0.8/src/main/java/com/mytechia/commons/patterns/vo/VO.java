
package com.mytechia.commons.patterns.vo;


/**
 * Interfaz para "Objetos Valor" o "JavaBeans".
 */
public interface VO extends java.io.Serializable {   
    
}
