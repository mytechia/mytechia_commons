

package com.mytechia.commons.logger;



public class MainClass {
    
    public static void main(String ...args){
        
        System.out.println("The main class is executing");
        
    }

}
